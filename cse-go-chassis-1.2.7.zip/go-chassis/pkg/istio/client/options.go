package client

// PilotOptions defines options to new client
type PilotOptions struct {
	Endpoints []string
}
