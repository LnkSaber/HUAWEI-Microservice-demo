package microservice.demo.training21days.provider.service;

public enum Gender {
  MALE,
  FEMALE
}
