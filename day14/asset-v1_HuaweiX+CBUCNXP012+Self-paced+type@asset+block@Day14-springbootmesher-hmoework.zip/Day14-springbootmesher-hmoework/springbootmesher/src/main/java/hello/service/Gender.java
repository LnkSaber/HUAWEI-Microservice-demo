package hello.service;

public enum  Gender {
    MALE,
    FEMALE
}
