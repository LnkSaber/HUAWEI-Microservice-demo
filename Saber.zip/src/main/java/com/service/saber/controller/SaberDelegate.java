package com.service.saber.controller;

import org.springframework.stereotype.Component;


@Component
public class SaberDelegate {

    public String helloworld(String name){

        // Do Some Magic Here!
        return name;
    }
}
