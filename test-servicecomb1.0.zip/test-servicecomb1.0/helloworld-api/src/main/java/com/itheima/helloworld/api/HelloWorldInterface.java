package com.itheima.helloworld.api;

import com.itheima.model.helloworld.Student;


public interface HelloWorldInterface {

    Student hello(String name);
}
