This is a very simple web app with a Java Servlet. 
