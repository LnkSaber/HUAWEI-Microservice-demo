package com.saber.service;

//微服务接口定义
public interface RestService {
    String sayRest(String name);
}
