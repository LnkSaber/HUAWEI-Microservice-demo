#!/usr/bin/env bash

cd ./console
sh stop.sh
cd ../local-cse-config-center
sh stop.sh
cd ../local-service-center
sh stop.sh